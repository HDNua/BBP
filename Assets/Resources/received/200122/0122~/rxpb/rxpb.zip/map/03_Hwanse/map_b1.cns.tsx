<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="map_b1.cns" tilewidth="16" tileheight="16" tilecount="480" columns="40">
 <image source="../../bmp/map/map_b1.cns.bmp" width="640" height="192"/>
</tileset>
