<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="TempTileSet" tilewidth="16" tileheight="16" tilecount="512" columns="32">
 <image source="../../JErGKO5.png" width="512" height="256"/>
</tileset>
