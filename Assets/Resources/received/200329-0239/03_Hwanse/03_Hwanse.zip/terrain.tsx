<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="tt" tilewidth="16" tileheight="16" tilecount="90" columns="6">
 <image source="terrain.png" width="96" height="240"/>
</tileset>
