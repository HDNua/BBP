<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="2" tilewidth="16" tileheight="16" tilecount="8" columns="4">
 <image source="../../결과물aseprite/2.png" width="64" height="32"/>
</tileset>
